<footer id="footer"> 
    <!--quote-container Start Here -->
    <div class="quote-container">
      <div class="right-banner"></div>
      <div class="container">
        <div class="row">
          <div class="col-xs-12">
            <center><div class="quote-box animate-effect">
              <h4>GE Health Care TATA training Center of Excellence for Operation Theater Technician& Paramedical Staff<i></i></h4>
            
				
<img src="images/ge-healthcare.jpg" alt="Mountain View"  width="250" height="250">  




       </div>
</center>
          </div>
        </div>
      </div>
    </div>
    <!--quote-container End Here --> 
    <!--contact-us-container Start Here -->
 
    <!--contact-us-container End Here -->
    
    <div class="primary-footer">
      <div class="container">
        <div class="row animate-effect">
          <div class="col-xs-12 col-sm-3">
            <h3>CONTACT US <i></i></h3>
              <div class="box"> 
			  <p>Fort View Colony, Upparpally,<p>
				<p>	 Rajendranagar, Opp. Pillar No. 191,</p>
				<p> PVNR express flyover.</p> </div>
			    <div class="box call">
				<p><i class="fa fa-mobile"></i> <strong> +91 92465 99936</strong></p>
				<p><i class="fa fa-mobile"></i> <strong> +91 99896 35555</strong> </p>
				<p> <a href="mailto:mjzk5565@gmail.com" style="color:#9a9a9a;"><i class="fa fa-envelope"></i>  mjzk5565@gmail.com</a></p> </div>
          </div>
          <div class="col-xs-12 col-sm-3">
            <h3>navigation <i></i></h3>
            <ul class="list clearfix">
              <li> <a href="index.php">Home</a> </li>
              <li> <a href="testimonials.php">Testimonials</a> </li>
			  <li> <a href="vision-mission.php">Our Vision</a> </li>
              <li> <a href="faqs.php">FAQ'S</a> </li>
              <li> <a href="contact.php">Contact us</a> </li>
            </ul>
          </div>
          <div class="col-xs-12 col-sm-3">
            <h3>Special Procedures <i></i></h3>
            
             <ul class="list clearfix">
              <li> <a href="joint-replacement.php">Hip Replacement</a> </li>
              <li> <a href="joint-replacement.php">Knee Replacement</a> </li>
              <li> <a href="arthroscopy.php">Arthroscopic Surgery</a> </li>
              <li> <a href="spine-surgery.php">Spine Surgical Treatments</a> </li>
			   <li> <a href="knee-joint-replacement.php">Makoplasty</a> </li>
			   <li> <a href="knee-joint-replacement.php">Partial Knee Replacement</a> </li>
            </ul>
            
          </div>
		    <div class="col-xs-12 col-sm-3">
            <h3>Follow Us  <i></i></h3>
            
             <div class="box call">
              <ul class="socialIcons">
                <li> <a href="#"><i class="fa fa-facebook"></i></a> </li>
                <li> <a href="#"><i class="fa fa-twitter"></i></a> </li>
                <li> <a href="#"><i class="fa fa-google-plus"></i></a> </li>
                <li> <a href="#"><i class="fa fa-youtube"></i></a> </li>
				<div class="clearfix"></div>
              </ul>
            </div>
            <div class="box call bank"> 
			<span><p>Banking Partner<p> 
			<img src="images/synd.png" alt="Smiley face" height="42" width="155"> </span> </div>
          </div>
        </div>
        <div class="row animate-effect">
          <div class="col-xs-12 copyright"> <span>Copyright © 2017 Human Touch Hospitals. All rights reserved.</span> </div>
        </div>
      </div>
    </div>
  </footer>